#KH
#Advanced Computer Programming (10)
#03/16/19
#V 1.0.0

'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
#####
Howard C Davis
Final Tk
'''

import pygame, sys
import random

# Color
WHITE = (255, 255, 255)
RED = (255, 0, 0)

#width and height of ship
SX = 83
SY = 160

AMOUNT = 5
MaxB = 6
SCORE = 0

angle = 270

SPAWNTIME = 350
MAXA = 20
LOSE = 0
START = 0
LIFE = 3
RESTART = 0
start = 0  #3000 ~ one minute

TOP = []
TOP10 = []
CHANGE = 0
CHANGEW = 0

Aspeed = -5

#Sounds/Music
'''BKGM = pygame.mixer.music.load("Undertale-Megalovania.mp3")
BKGM = pygame.mixer.music.play(-1, 0.0)
BKGM = pygame.mixer.music.set_volume(.2)'''


class Entity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, x, y, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # This makes a rectangle around the entity, used for anything
        # from collision to moving around.
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

#Player class
class Player(Entity):
    # The player controlled Paddle

    def __init__(self, x, y, width, height, angle):
        super(Player, self).__init__(x, y, width, height - 100)

        self.height = height
        self.width = width

        self.angle = angle

        self.image = pygame.image.load("Lava.png")
        self.image = pygame.transform.scale(self.image, (SX, SY))
        self.image = pygame.transform.rotate(self.image, self.angle)
        self.rect = self.image.get_rect()

        self.rect = self.image.get_rect()

        # How many pixels the Player Paddle should move on a given frame.
        self.y_change = 0
        self.x_change = 0
        # How many pixels the paddle should move each frame a key is pressed.
        self.y_dist = 8
        self.x_distf = 4
        self.x_distb = 8

    def MoveKeyDown(self, key):
        # Responds to a key-down event and moves accordingly
        if (key == pygame.K_UP) or (key == ord('w')):
            self.y_change += -self.y_dist
        elif (key == pygame.K_DOWN) or (key == ord('s')):
            self.y_change += self.y_dist
        elif (key == pygame.K_RIGHT) or (key == ord('d')):
            self.x_change += self.x_distf
        elif (key == pygame.K_LEFT) or (key == ord('a')):
            self.x_change += -self.x_distb

    def MoveKeyUp(self, key):
        # Responds to a key-up event and stops movement accordingly
        if (key == pygame.K_UP) or (key == ord('w')):
            self.y_change += self.y_dist
        elif (key == pygame.K_DOWN) or (key == ord('s')):
            self.y_change += -self.y_dist
        elif (key == pygame.K_RIGHT) or (key == ord('d')):
            self.x_change += -self.x_distf
        elif (key == pygame.K_LEFT) or (key == ord('a')):
            self.x_change += self.x_distb

    def update(self):

        # Moves the paddle while ensuring it stays in bounds

        # Moves it relative to its current location.
        self.rect.move_ip(self.x_change, self.y_change)
        # self.image = pygame.transform.rotate(self.image, self.angle)

        # If the paddle moves off the screen, put it back on.
        if self.rect.y < 0:
            self.rect.y = 0
        if self.rect.x < 30:
            self.rect.x = 30
        if self.rect.y > window_height - self.height:
            self.rect.y = window_height - self.height
        if self.rect.x > window_width:
            self.rect.x = window_width

#Asteroid class
class Asteroid(Entity):
    def __init__(self, x, y, width, height):
        super(Asteroid, self).__init__(x, y, width, height)
        self.image = pygame.image.load("Asteroid.png")
        self.image = pygame.transform.scale(self.image, (100, 60))
        self.x_change = Aspeed
        self.y_change = 0

    def update(self):
        global SCORE
        self.rect.move_ip(self.x_change, self.y_change)
        if self.rect.x < 0:
            Asteroid.kill(self)
            SCORE -= 100

#Bullet class
class Bullet(Entity):
    def __init__(self, x, y, width, height):
        super(Bullet, self).__init__(x, y, width, height)

        self.image = pygame.Surface([width, height])
        self.image.fill(RED)

        self.x_change = 10
        self.y_change = 0

    def update(self):
        global SCORE
        global LIFE

        self.rect.move_ip(self.x_change, self.y_change)
        if self.rect.x > window_width:
            Bullet.kill(self)

        for bullet in All_Bullets:
            hitA = pygame.sprite.spritecollide(bullet, All_Asteroids, True)
            for Ast in hitA:
                Bullet.kill(self)
                SCORE += 100
                EXPWOSON()


#Score
class ShowScore:
    def __init__(self):
        self.font = pygame.font.SysFont('comicsansms', 40)
        self.textSurface = self.font.render("Score: %s" %str(SCORE), True, WHITE)
        self.textRect = self.textSurface.get_rect()
        self.textRect.center = (window_width - 200, 30)

#Lives
class Life:
    def __init__(self):
        self.font = pygame.font.SysFont('comicsansms', 40)
        self.textSurface = self.font.render("Lives: %s" %str(LIFE), True, WHITE)
        self.textRect = self.textSurface.get_rect()
        self.textRect.center = (window_width/2, 30)

#Start screen
class STARTSCREEN:
    def __init__(self):
        self.fontObjB = pygame.font.SysFont('comicsansms', 70)
        self.fontObj = pygame.font.SysFont('comicsansms', 40)

        self.textSurfaceObjE = self.fontObjB.render("How to play:", True, WHITE)
        self.textRectObjE = self.textSurfaceObjE.get_rect()
        self.textRectObjE.center = ((window_width / 2), 60)

        self.HowToPlay = self.fontObj.render("How to play:", True, WHITE)
        self.HowToPlayRect = self.HowToPlay.get_rect()
        self.HowToPlayRect.center = ((window_width / 2), 120)

        self.NumOne = self.fontObj.render("1: To control the ship, use the W A S D keys or the arrow keys", True, WHITE)
        self.NumOneRect = self.NumOne.get_rect()
        self.NumOneRect.center = ((window_width / 2), 180)

        self.Space = self.fontObj.render("2: Press SPACE to fire", True, WHITE)
        self.SpaceRect = self.Space.get_rect()
        self.SpaceRect.center = ((window_width / 2), 260)

        self.NumTwo1 = self.fontObj.render(
            "3: You will either lose if you go under 0 points", True, WHITE)
        self.NumTwoRect1 = self.NumTwo1.get_rect()
        self.NumTwoRect1.center = ((window_width / 2), 340)
        self.NumTwo2 = self.fontObj.render(
            "or you lose all of your lives", True, WHITE)
        self.NumTwoRect2 = self.NumTwo2.get_rect()
        self.NumTwoRect2.center = ((window_width / 2), 420)

        self.NumThree = self.fontObj.render("4: There is a chance to get a more lives", True, WHITE)
        self.NumThreeRect = self.NumThree.get_rect()
        self.NumThreeRect.center = ((window_width / 2), 500)

        self.Start = self.fontObjB.render("Press ENTER to start", True, WHITE)
        self.StartRect = self.Start.get_rect()
        self.StartRect.center = ((window_width / 2), 600)

#Adds asteroids
def add():
    for i in range(AMOUNT):
        y = random.randrange(window_height - 100)
        x = random.randrange(window_width)
        asteroid = Asteroid(window_width + x, y, 50, 50)
        All_Asteroids.add(asteroid)
        all_sprites_list.add(asteroid)

    R = random.randrange(1,6)
    if R == 5:
        y = random.randrange(window_height - 100)
        x = random.randrange(window_width)
        power = Powerup(window_width + x, y, 60,60)
        all_sprites_list.add(power)
        ALL_POWERUPS.add(power)

#Adds the power up
class Powerup(Entity):
    def __init__(self, x, y, width, height):
        super(Powerup, self).__init__(x, y, width, height)
        self.image = pygame.image.load("Heart.png")
        self.image = pygame.transform.scale(self.image, (60, 60))
        self.x_change = -5
        self.y_change = 0

    def update(self):
        global LIFE
        self.rect.move_ip(self.x_change, self.y_change)
        if self.rect.x < 0:
            Powerup.kill(self)

        for power in ALL_POWERUPS:
            hitA = pygame.sprite.spritecollide(power, All_Bullets, True)
            for pow in hitA:
                Powerup.kill(self)
                LIFE += 1
                Heal()

#Sounds
def PEW():#Plays sound number 1
    APS = pygame.mixer.Sound("PEW.wav")  #APS = Air Plane Ding
    APS.play()

def EXPWOSON():  #Plays sound number 1
    APS = pygame.mixer.Sound("EXPWOSON.wav")  #APS = Air Plane Ding
    APS.play()

def Heal():  #Plays sound number 1
    APS = pygame.mixer.Sound("Heal.wav")  #APS = Air Plane Ding
    APS.play()


pygame.init()

pygame.display.set_caption("Asteroid Game")

clock = pygame.time.Clock()

window_width = 1200
window_height = 700
screen = pygame.display.set_mode((window_width, window_height))

player = Player(50, window_height / 2, SY, SX, angle)  # X,Y,W,H

all_sprites_list = pygame.sprite.Group()
All_Asteroids = pygame.sprite.Group()
All_Bullets = pygame.sprite.Group()
ALL_POWERUPS = pygame.sprite.Group()
all_sprites_list.add(player)

#Sounds/Music
DEJAVU = pygame.mixer.music.load("DEJAVU.mp3")


for A in All_Asteroids:
    all_sprites_list.add(A)

space = pygame.image.load("SpaceBG.png")

pygame.mixer.init(22100, -16, 2, 64)

while True:
    # Event processing here
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            player.MoveKeyDown(event.key)

            if event.key == pygame.K_SPACE:
                if LOSE == 0 and START == 1:
                    if len(All_Bullets) <= 10:
                        x = int(player.rect.x)
                        y = int(player.rect.y)
                        # Fire a bullet if the user clicks the mouse button
                        bullet = Bullet(player.rect.x, player.rect.y, 25, 6)
                        # Set the bullet so it is where the player is
                        bullet.rect.x = player.rect.x + player.width - 30
                        bullet.rect.y = player.rect.y + (player.height/2) - 3
                        # Add the bullet to the lists
                        all_sprites_list.add(bullet)
                        All_Bullets.add(bullet)
                        PEW()
                    else:
                        pass
                else:
                    pass

            elif event.key == pygame.K_RETURN:
                if START == 2:
                    START = 1
                    DEJAVU = pygame.mixer.music.play(-1, 0.0)
                    DEJAVU = pygame.mixer.music.set_volume(.5)
                elif RESTART == 1:
                    SCORE = 0
                    LIFE = 3
                    LOSE = 0
                    START = 1
                    AMOUNT = 5
                    start = 0
                    SPAWNTIME = 350
                    All_Asteroids = pygame.sprite.Group()
                    All_Bullets = pygame.sprite.Group()
                    all_sprites_list = pygame.sprite.Group()
                    all_sprites_list.add(player)

            elif event.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()

        elif event.type == pygame.KEYUP:
            player.MoveKeyUp(event.key)

    if START == 0:
        START = 2
        # screen.blit(space, (0, 0))
        startS = STARTSCREEN()
        Surface = startS.textSurfaceObjE
        Rect = startS.textRectObjE
        Surface1 = startS.NumOne
        Rect1 = startS.NumOneRect
        SurfaceSpace = startS.Space
        RectSpace = startS.SpaceRect
        Surface21 = startS.NumTwo1
        Rect21 = startS.NumTwoRect1
        Surface22 = startS.NumTwo2
        Rect22 = startS.NumTwoRect2
        Surface3 = startS.NumThree
        Rect3 = startS.NumThreeRect
        SurfaceS = startS.Start
        RectS = startS.StartRect

        screen.blit(Surface, Rect)
        screen.blit(Surface1, Rect1)
        screen.blit(SurfaceSpace, RectSpace)
        screen.blit(Surface21, Rect21)
        screen.blit(Surface22, Rect22)
        screen.blit(Surface3, Rect3)
        screen.blit(SurfaceS, RectS)

        pygame.display.flip()


    if LOSE == 0 and START == 1:
        if len(All_Asteroids) <= MAXA:
            if start <= 0:
                add()
                start = SPAWNTIME
                AMOUNT += 1
                SPAWNTIME -= 1
                if Aspeed <= .2:
                    Aspeed -= .2
                else:
                    pass
            else:
                start -= 1

        elif len(All_Asteroids) >= MAXA:
            if start <= 0:
                start = SPAWNTIME
                if Aspeed <= .2:
                    Aspeed -= .2
                else:
                    pass
            else:
                start -= 1

        for ent in all_sprites_list:
            ent.update()

        for AllAst in All_Asteroids:
            hit = pygame.sprite.spritecollide(player, All_Asteroids, True)
            for Ast in hit:
                AMOUNT += 1
                Asteroid.kill(Ast)
                LIFE -= 1

        for AllPow in ALL_POWERUPS:
            hit = pygame.sprite.spritecollide(player, ALL_POWERUPS, True)
            for Pow in hit:
                Powerup.kill(Pow)
                if LIFE != 5:
                    LIFE += 1
                    Heal()
                else:
                    pass

        if LIFE <= 0 or SCORE < 0:
            LOSE = 1
            RESTART = 1

        all_sprites_list.draw(screen)

        pygame.display.flip()

        Text = ShowScore()
        Surface = Text.textSurface
        Rect = Text.textRect

        Lives = Life()
        SurfaceL = Lives.textSurface
        RectL = Lives.textRect

        screen.blit(space, (0, 0))
        screen.blit(Surface, Rect)
        screen.blit(SurfaceL, RectL)

    elif LOSE == 1:
        LOSE = 2
        all_sprites_list.draw(screen)

        pygame.display.flip()

        Scores = open("Asteroid_Scores.txt", "r")
        for i in Scores:
            TOP.append(i.replace("\n",""))
            pass
        Scores.close()

        #print(TOP10)
        TOP = sorted(TOP, key=int)
        if CHANGE == 0:
            for i in TOP:
                if CHANGE == 0:
                    if int(i) >= SCORE:
                        TOP10.append(int(i))
                    elif int(i) < SCORE:
                        TOP10.append(SCORE)
                        CHANGE = 1
                else:
                    TOP10.append(int(i))
            CHANGE = 1
        else:
            pass

        TOP10 = sorted(TOP10, key=int, reverse=True)

        Scores = open("Asteroid_Scores.txt", "a")
        if CHANGEW == 0:
            #This emties the file
            Scores2 = open("Asteroid_Scores.txt", "w")
            Scores2.close()
            for i in TOP10:
                Scores.write("%s\n"%str(i))
            CHANGEW = 1
        elif CHANGEW == 1:
            pass
        Scores.close()

        fontObj = pygame.font.SysFont('comicsansms', 40)

        textSurfaceObjL = fontObj.render("Top 10 Scores:", True, WHITE)
        textRectObjL = textSurfaceObjL.get_rect()
        textRectObjL.center = ((window_width / 5), 30)

        distance = 60

        textSurfaceObj1 = fontObj.render("1: %s"%TOP10[0], True, WHITE)
        textRectObj1 = textSurfaceObj1.get_rect()
        textRectObj1.center = ((window_width / 5), distance+50)

        textSurfaceObj2 = fontObj.render("2: %s"%TOP10[1], True, WHITE)
        textRectObj2 = textSurfaceObj2.get_rect()
        textRectObj2.center = ((window_width / 5), distance*2+50)

        textSurfaceObj3 = fontObj.render("3: %s"%TOP10[2], True, WHITE)
        textRectObj3 = textSurfaceObj3.get_rect()
        textRectObj3.center = ((window_width / 5), distance*3+50)

        textSurfaceObj4 = fontObj.render("4: %s"%TOP10[3], True, WHITE)
        textRectObj4 = textSurfaceObj4.get_rect()
        textRectObj4.center = ((window_width / 5), distance*4+50)

        textSurfaceObj5 = fontObj.render("5: %s"%TOP10[4], True, WHITE)
        textRectObj5 = textSurfaceObj5.get_rect()
        textRectObj5.center = ((window_width / 5), distance*5+50)

        textSurfaceObj6 = fontObj.render("6: %s"%TOP10[5], True, WHITE)
        textRectObj6 = textSurfaceObj6.get_rect()
        textRectObj6.center = ((window_width / 5), distance*6+50)

        textSurfaceObj7 = fontObj.render("7: %s"%TOP10[6], True, WHITE)
        textRectObj7 = textSurfaceObj7.get_rect()
        textRectObj7.center = ((window_width / 5), distance*7+50)

        textSurfaceObj8 = fontObj.render("8: %s"%TOP10[7], True, WHITE)
        textRectObj8 = textSurfaceObj8.get_rect()
        textRectObj8.center = ((window_width / 5), distance*8+50)

        textSurfaceObj9 = fontObj.render("9: %s"%TOP10[8], True, WHITE)
        textRectObj9 = textSurfaceObj9.get_rect()
        textRectObj9.center = ((window_width / 5), distance*9+50)

        textSurfaceObj10 = fontObj.render("10: %s" % TOP10[9], True, WHITE)
        textRectObj10 = textSurfaceObj10.get_rect()
        textRectObj10.center = ((window_width / 5), distance * 10 + 50)

        textSurfaceObjEnter = fontObj.render("Press Enter To Play Again", True, WHITE)
        textRectObjEnter = textSurfaceObjEnter.get_rect()
        textRectObjEnter.center = ((window_width - window_width / 3), window_height / 2)

        screen.blit(textSurfaceObjL, textRectObjL)
        screen.blit(textSurfaceObj1, textRectObj1)
        screen.blit(textSurfaceObj2, textRectObj2)
        screen.blit(textSurfaceObj3, textRectObj3)
        screen.blit(textSurfaceObj4, textRectObj4)
        screen.blit(textSurfaceObj5, textRectObj5)
        screen.blit(textSurfaceObj6, textRectObj6)
        screen.blit(textSurfaceObj7, textRectObj7)
        screen.blit(textSurfaceObj8, textRectObj8)
        screen.blit(textSurfaceObj9, textRectObj9)
        screen.blit(textSurfaceObj10, textRectObj10)
        screen.blit(textSurfaceObjEnter, textRectObjEnter)

        pygame.display.flip()

    clock.tick(60)